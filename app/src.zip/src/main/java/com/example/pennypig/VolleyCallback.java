package com.example.pennypig;

public interface VolleyCallback {
    void onSuccess(String result);
}
